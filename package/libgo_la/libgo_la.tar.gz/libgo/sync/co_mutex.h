#pragma once
#include "../common/config.h"
#include "../routine_sync/mutex.h"

namespace co
{

typedef libgo::Mutex CoMutex;
typedef CoMutex co_mutex;

} //namespace co
