#pragma once

#define ENABLE_DEBUGGER 0

#define ENABLE_HOOK 1

